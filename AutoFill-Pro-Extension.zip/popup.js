// AutoFill Pro Popup Script
// 处理弹出窗口的交互逻辑

class AutoFillPopup {
  constructor() {
    this.currentTab = null;
    this.profiles = {};
    this.settings = {};
    this.formsData = null;
    
    this.init();
  }

  async init() {
    console.log('[AutoFill Pro] Popup initialized');
    
    // 获取当前标签页信息
    await this.getCurrentTab();
    
    // 加载数据
    await this.loadData();
    
    // 初始化UI
    this.initializeUI();
    
    // 设置事件监听
    this.setupEventListeners();
    
    // 检测表单
    this.detectForms();
  }

  async getCurrentTab() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      this.currentTab = tab;
      
      // 获取标签页详细信息
      const response = await chrome.runtime.sendMessage({
        type: 'GET_TAB_INFO'
      });
      
      if (response.success) {
        this.tabInfo = response.info;
        this.updateSiteInfo();
      }
    } catch (error) {
      console.error('[AutoFill Pro] Get current tab error:', error);
      this.showMessage('获取页面信息失败', 'error');
    }
  }

  async loadData() {
    try {
      // 加载用户配置文件
      const profilesResponse = await chrome.runtime.sendMessage({
        type: 'GET_PROFILES'
      });
      
      if (profilesResponse.success) {
        this.profiles = profilesResponse.profiles;
        this.updateProfileSelector();
      }
      
      // 加载设置
      const settingsResponse = await chrome.runtime.sendMessage({
        type: 'GET_SETTINGS'
      });
      
      if (settingsResponse.success) {
        this.settings = settingsResponse.settings;
      }
    } catch (error) {
      console.error('[AutoFill Pro] Load data error:', error);
    }
  }

  initializeUI() {
    // 更新状态
    this.updateStatus();
    
    // 设置按钮状态
    this.updateButtonStates();
  }

  setupEventListeners() {
    // 检测表单按钮
    document.getElementById('detectBtn').addEventListener('click', () => {
      this.detectForms();
    });
    
    // 一键填写按钮
    document.getElementById('fillBtn').addEventListener('click', () => {
      this.fillForms();
    });
    
    // 设置按钮
    document.getElementById('settingsBtn').addEventListener('click', () => {
      this.openSettings();
    });
    
    // 配置文件选择
    document.getElementById('profileSelect').addEventListener('change', (e) => {
      this.onProfileChange(e.target.value);
    });
    
    // 帮助链接
    document.getElementById('helpLink').addEventListener('click', (e) => {
      e.preventDefault();
      this.openHelp();
    });
    
    // 反馈链接
    document.getElementById('feedbackLink').addEventListener('click', (e) => {
      e.preventDefault();
      this.openFeedback();
    });
  }

  updateSiteInfo() {
    if (!this.tabInfo) return;
    
    const siteNameEl = document.getElementById('siteName');
    const siteUrlEl = document.getElementById('siteUrl');
    
    if (this.tabInfo.supported) {
      siteNameEl.textContent = this.tabInfo.websiteRule.name;
      siteNameEl.style.color = '#28a745';
    } else {
      siteNameEl.textContent = this.tabInfo.hostname;
      siteNameEl.style.color = '#666';
    }
    
    siteUrlEl.textContent = this.tabInfo.url;
  }

  updateStatus() {
    const statusDot = document.getElementById('statusDot');
    const statusText = document.getElementById('statusText');
    
    if (this.tabInfo && this.tabInfo.supported) {
      statusDot.classList.add('active');
      statusText.textContent = '支持自动填写';
    } else {
      statusDot.classList.remove('active');
      statusText.textContent = '不支持此网站';
    }
  }

  updateProfileSelector() {
    const profileSelect = document.getElementById('profileSelect');
    
    // 清空现有选项
    profileSelect.innerHTML = '<option value="">选择配置文件...</option>';
    
    // 添加配置文件选项
    Object.values(this.profiles).forEach(profile => {
      const option = document.createElement('option');
      option.value = profile.id;
      option.textContent = profile.name || '未命名配置';
      profileSelect.appendChild(option);
    });
    
    // 如果没有配置文件，添加创建提示
    if (Object.keys(this.profiles).length === 0) {
      const option = document.createElement('option');
      option.value = 'create';
      option.textContent = '创建新配置文件...';
      profileSelect.appendChild(option);
    }
  }

  updateButtonStates() {
    const fillBtn = document.getElementById('fillBtn');
    const profileSelect = document.getElementById('profileSelect');
    
    // 只有选择了配置文件且检测到表单时才能填写
    const canFill = profileSelect.value && 
                   profileSelect.value !== 'create' && 
                   this.formsData && 
                   this.formsData.formsCount > 0;
    
    fillBtn.disabled = !canFill;
  }

  async detectForms() {
    const detectBtn = document.getElementById('detectBtn');
    const formsCountEl = document.getElementById('formsCount');
    
    try {
      // 显示加载状态
      detectBtn.innerHTML = '<div class="loading"></div><span>检测中...</span>';
      detectBtn.disabled = true;
      
      // 发送消息到content script
      const response = await chrome.tabs.sendMessage(this.currentTab.id, {
        type: 'DETECT_FORMS'
      });
      
      if (response && response.success) {
        this.formsData = response.data;
        formsCountEl.textContent = this.formsData.formsCount;
        
        if (this.formsData.formsCount > 0) {
          this.showMessage(`检测到 ${this.formsData.formsCount} 个表单`, 'success');
        } else {
          this.showMessage('未检测到可填写的表单', 'error');
        }
      } else {
        this.showMessage('表单检测失败', 'error');
        formsCountEl.textContent = '0';
      }
    } catch (error) {
      console.error('[AutoFill Pro] Detect forms error:', error);
      this.showMessage('表单检测失败，请刷新页面后重试', 'error');
      formsCountEl.textContent = '0';
    } finally {
      // 恢复按钮状态
      detectBtn.innerHTML = '<span>🔍</span><span>检测表单</span>';
      detectBtn.disabled = false;
      this.updateButtonStates();
    }
  }

  async fillForms() {
    const fillBtn = document.getElementById('fillBtn');
    const profileSelect = document.getElementById('profileSelect');
    
    const selectedProfileId = profileSelect.value;
    if (!selectedProfileId || selectedProfileId === 'create') {
      this.showMessage('请先选择配置文件', 'error');
      return;
    }
    
    const profile = this.profiles[selectedProfileId];
    if (!profile) {
      this.showMessage('配置文件不存在', 'error');
      return;
    }
    
    try {
      // 显示加载状态
      fillBtn.innerHTML = '<div class="loading"></div><span>填写中...</span>';
      fillBtn.disabled = true;
      
      // 发送填写消息到content script
      const response = await chrome.tabs.sendMessage(this.currentTab.id, {
        type: 'FILL_FORMS',
        payload: {
          profile: profile,
          settings: this.settings
        }
      });
      
      if (response && response.success) {
        this.showMessage(`成功填写 ${response.filledCount} 个字段`, 'success');
        
        // 如果设置了自动提交，显示提示
        if (this.settings.autoSubmit && response.submitted) {
          this.showMessage('表单已自动提交', 'success');
        }
      } else {
        this.showMessage(response?.error || '填写失败', 'error');
      }
    } catch (error) {
      console.error('[AutoFill Pro] Fill forms error:', error);
      this.showMessage('填写失败，请重试', 'error');
    } finally {
      // 恢复按钮状态
      fillBtn.innerHTML = '<span>✨</span><span>一键填写</span>';
      fillBtn.disabled = false;
    }
  }

  onProfileChange(profileId) {
    if (profileId === 'create') {
      // 打开设置页面创建新配置文件
      this.openSettings();
      return;
    }
    
    this.updateButtonStates();
  }

  openSettings() {
    chrome.tabs.create({ url: chrome.runtime.getURL('options.html') });
    window.close();
  }

  openHelp() {
    chrome.tabs.create({ url: 'https://github.com/autofill-pro/help' });
    window.close();
  }

  openFeedback() {
    chrome.tabs.create({ url: 'https://github.com/autofill-pro/feedback' });
    window.close();
  }

  showMessage(text, type = 'success') {
    const messageEl = document.getElementById('message');
    messageEl.textContent = text;
    messageEl.className = `message ${type}`;
    messageEl.style.display = 'block';
    
    // 3秒后自动隐藏
    setTimeout(() => {
      messageEl.style.display = 'none';
    }, 3000);
  }
}

// 当DOM加载完成时初始化
document.addEventListener('DOMContentLoaded', () => {
  new AutoFillPopup();
});