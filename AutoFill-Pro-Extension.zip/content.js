// AutoFill Pro Content Script
// 负责表单检测、字段识别和自动填写功能

class AutoFillContentScript {
  constructor() {
    this.isInitialized = false;
    this.detectedForms = [];
    this.websiteRules = {};
    this.currentProfile = null;
    this.init();
  }

  async init() {
    if (this.isInitialized) return;
    
    console.log('[AutoFill Pro] Content script initialized on:', window.location.hostname);
    
    // 加载网站规则
    await this.loadWebsiteRules();
    
    // 检测页面表单
    this.detectForms();
    
    // 监听消息
    this.setupMessageListener();
    
    // 监听DOM变化
    this.setupMutationObserver();
    
    this.isInitialized = true;
  }

  async loadWebsiteRules() {
    try {
      const result = await chrome.storage.local.get(['websiteRules']);
      this.websiteRules = result.websiteRules || this.getDefaultRules();
    } catch (error) {
      console.error('[AutoFill Pro] Failed to load website rules:', error);
      this.websiteRules = this.getDefaultRules();
    }
  }

  getDefaultRules() {
    const hostname = window.location.hostname;
    
    // 默认网站规则配置
    const defaultRules = {
      'linkedin.com': {
        name: 'LinkedIn',
        selectors: {
          firstName: ['input[name="firstName"]', '#firstName', 'input[aria-label*="First name"]'],
          lastName: ['input[name="lastName"]', '#lastName', 'input[aria-label*="Last name"]'],
          email: ['input[type="email"]', 'input[name="email"]', 'input[aria-label*="Email"]'],
          phone: ['input[type="tel"]', 'input[name="phone"]', 'input[aria-label*="Phone"]'],
          location: ['input[name="location"]', 'input[aria-label*="Location"]'],
          company: ['input[name="company"]', 'input[aria-label*="Company"]']
        }
      },
      'indeed.com': {
        name: 'Indeed',
        selectors: {
          firstName: ['input[name="applicant.name.first"]', '#applicant-firstName'],
          lastName: ['input[name="applicant.name.last"]', '#applicant-lastName'],
          email: ['input[name="applicant.emailAddress"]', '#applicant-emailAddress'],
          phone: ['input[name="applicant.phoneNumber"]', '#applicant-phoneNumber'],
          location: ['input[name="applicant.location"]', '#applicant-location']
        }
      },
      'zhipin.com': {
        name: 'Boss直聘',
        selectors: {
          name: ['input[placeholder*="姓名"]', 'input[name="name"]'],
          phone: ['input[placeholder*="手机"]', 'input[name="mobile"]', 'input[type="tel"]'],
          email: ['input[placeholder*="邮箱"]', 'input[name="email"]', 'input[type="email"]'],
          location: ['input[placeholder*="所在地"]', 'input[name="location"]']
        }
      },
      'lagou.com': {
        name: '拉勾网',
        selectors: {
          name: ['input[placeholder*="姓名"]', '#name'],
          phone: ['input[placeholder*="手机号"]', '#phone'],
          email: ['input[placeholder*="邮箱"]', '#email']
        }
      }
    };

    return defaultRules[hostname] || this.getGenericRules();
  }

  getGenericRules() {
    return {
      name: 'Generic',
      selectors: {
        firstName: ['input[name*="first"]', 'input[id*="first"]', 'input[placeholder*="First"]'],
        lastName: ['input[name*="last"]', 'input[id*="last"]', 'input[placeholder*="Last"]'],
        name: ['input[name*="name"]', 'input[id*="name"]', 'input[placeholder*="Name"]', 'input[placeholder*="姓名"]'],
        email: ['input[type="email"]', 'input[name*="email"]', 'input[id*="email"]'],
        phone: ['input[type="tel"]', 'input[name*="phone"]', 'input[name*="mobile"]', 'input[placeholder*="Phone"]'],
        location: ['input[name*="location"]', 'input[name*="address"]', 'input[placeholder*="Location"]']
      }
    };
  }

  detectForms() {
    const forms = document.querySelectorAll('form');
    this.detectedForms = [];

    forms.forEach((form, index) => {
      const fields = this.analyzeForm(form);
      if (fields.length > 0) {
        this.detectedForms.push({
          id: `form_${index}`,
          element: form,
          fields: fields,
          score: this.calculateFormScore(fields)
        });
      }
    });

    // 通知background script检测到的表单
    if (this.detectedForms.length > 0) {
      chrome.runtime.sendMessage({
        type: 'FORMS_DETECTED',
        payload: {
          url: window.location.href,
          domain: window.location.hostname,
          formsCount: this.detectedForms.length,
          totalFields: this.detectedForms.reduce((sum, form) => sum + form.fields.length, 0)
        }
      });
    }
  }

  analyzeForm(form) {
    const fields = [];
    const inputs = form.querySelectorAll('input, select, textarea');
    const rules = this.websiteRules;

    inputs.forEach(input => {
      const fieldType = this.identifyFieldType(input, rules);
      if (fieldType) {
        fields.push({
          element: input,
          type: fieldType,
          selector: this.generateSelector(input),
          required: input.required || input.getAttribute('aria-required') === 'true'
        });
      }
    });

    return fields;
  }

  identifyFieldType(input, rules) {
    const name = input.name?.toLowerCase() || '';
    const id = input.id?.toLowerCase() || '';
    const placeholder = input.placeholder?.toLowerCase() || '';
    const type = input.type?.toLowerCase() || '';
    const ariaLabel = input.getAttribute('aria-label')?.toLowerCase() || '';

    // 使用网站特定规则
    if (rules && rules.selectors) {
      for (const [fieldType, selectors] of Object.entries(rules.selectors)) {
        for (const selector of selectors) {
          if (input.matches(selector)) {
            return fieldType;
          }
        }
      }
    }

    // 通用字段识别
    if (type === 'email' || name.includes('email') || id.includes('email')) {
      return 'email';
    }
    if (type === 'tel' || name.includes('phone') || name.includes('mobile') || placeholder.includes('phone')) {
      return 'phone';
    }
    if (name.includes('first') && name.includes('name')) {
      return 'firstName';
    }
    if (name.includes('last') && name.includes('name')) {
      return 'lastName';
    }
    if (name.includes('name') && !name.includes('user') && !name.includes('company')) {
      return 'name';
    }
    if (name.includes('location') || name.includes('address') || name.includes('city')) {
      return 'location';
    }
    if (name.includes('company') || name.includes('organization')) {
      return 'company';
    }

    return null;
  }

  generateSelector(element) {
    if (element.id) {
      return `#${element.id}`;
    }
    if (element.name) {
      return `input[name="${element.name}"]`;
    }
    if (element.className) {
      return `.${element.className.split(' ')[0]}`;
    }
    return element.tagName.toLowerCase();
  }

  calculateFormScore(fields) {
    let score = 0;
    const importantFields = ['email', 'name', 'firstName', 'lastName', 'phone'];
    
    fields.forEach(field => {
      if (importantFields.includes(field.type)) {
        score += field.required ? 3 : 2;
      } else {
        score += 1;
      }
    });

    return score;
  }

  async fillForm(profileId, options = {}) {
    try {
      // 获取用户配置文件
      const result = await chrome.storage.local.get(['profiles']);
      const profiles = result.profiles || {};
      const profile = profiles[profileId];

      if (!profile) {
        throw new Error('Profile not found');
      }

      this.currentProfile = profile;
      const delay = options.delay || 500;
      let filledCount = 0;

      // 按表单评分排序，优先填写最重要的表单
      const sortedForms = this.detectedForms.sort((a, b) => b.score - a.score);

      for (const form of sortedForms) {
        for (const field of form.fields) {
          const value = this.getFieldValue(field.type, profile);
          if (value) {
            await this.fillField(field.element, value, delay);
            filledCount++;
          }
        }
      }

      // 通知填写完成
      chrome.runtime.sendMessage({
        type: 'FORM_FILLED',
        payload: {
          url: window.location.href,
          filledCount: filledCount,
          success: true
        }
      });

      return { success: true, filledCount };
    } catch (error) {
      console.error('[AutoFill Pro] Fill form error:', error);
      chrome.runtime.sendMessage({
        type: 'FORM_FILLED',
        payload: {
          url: window.location.href,
          success: false,
          error: error.message
        }
      });
      return { success: false, error: error.message };
    }
  }

  getFieldValue(fieldType, profile) {
    const fieldMap = {
      firstName: profile.fields?.firstName,
      lastName: profile.fields?.lastName,
      name: profile.fields?.firstName && profile.fields?.lastName 
        ? `${profile.fields.firstName} ${profile.fields.lastName}` 
        : profile.fields?.firstName || profile.fields?.lastName,
      email: profile.fields?.email,
      phone: profile.fields?.phone,
      location: profile.fields?.address?.city || profile.fields?.address?.full,
      company: profile.fields?.experience?.[0]?.company
    };

    return fieldMap[fieldType] || '';
  }

  async fillField(element, value, delay) {
    return new Promise((resolve) => {
      setTimeout(() => {
        try {
          // 聚焦元素
          element.focus();
          
          // 清空现有值
          element.value = '';
          
          // 触发input事件
          element.dispatchEvent(new Event('input', { bubbles: true }));
          
          // 设置新值
          element.value = value;
          
          // 触发change事件
          element.dispatchEvent(new Event('change', { bubbles: true }));
          element.dispatchEvent(new Event('blur', { bubbles: true }));
          
          resolve();
        } catch (error) {
          console.error('[AutoFill Pro] Fill field error:', error);
          resolve();
        }
      }, delay);
    });
  }

  setupMessageListener() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      switch (message.type) {
        case 'DETECT_FORMS':
          this.detectForms();
          sendResponse({ success: true, formsCount: this.detectedForms.length });
          break;
          
        case 'FILL_FORM':
          this.fillForm(message.payload.profileId, message.payload.options)
            .then(result => sendResponse(result))
            .catch(error => sendResponse({ success: false, error: error.message }));
          return true; // 异步响应
          
        case 'GET_FORM_INFO':
          sendResponse({
            success: true,
            forms: this.detectedForms.map(form => ({
              id: form.id,
              fieldsCount: form.fields.length,
              score: form.score,
              fields: form.fields.map(field => ({
                type: field.type,
                required: field.required
              }))
            }))
          });
          break;
      }
    });
  }

  setupMutationObserver() {
    const observer = new MutationObserver((mutations) => {
      let shouldRedetect = false;
      
      mutations.forEach((mutation) => {
        if (mutation.type === 'childList') {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              if (node.tagName === 'FORM' || node.querySelector('form')) {
                shouldRedetect = true;
              }
            }
          });
        }
      });
      
      if (shouldRedetect) {
        setTimeout(() => this.detectForms(), 1000);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
}

// 初始化content script
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    new AutoFillContentScript();
  });
} else {
  new AutoFillContentScript();
}